# Arbeitszeit Rechner – Android uygulaması

Bu uygulamada her gün:
- Tarih seçebilirsin.
- İşe başlama ve bitiş saatini girebilirsin.
- Mola süresini dakika olarak yazabilirsin.
- Uygulama mola süresini düşerek net çalışma süresini hesaplar.
- Bu ayın ve bu yılın toplamını gösterir.
- Kayıtları silebilir veya aynı tarihe yeni kayıt girerek düzeltebilirsin.

**Gece vardiyası:** Bitiş saati başlama saatinden küçük veya eşitse uygulama bitişi ertesi gün kabul eder.

**Veriler:** Kayıtlar telefonda yerel olarak saklanır. Uygulamayı kaldırırsan uygulama verileri silinebilir. Şimdilik bulut yedeklemesi yoktur.

## GitHub'a yükleme
1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP dosyasını bilgisayarında aç.
3. İçindeki `ArbeitszeitRechner` klasörünün dosyalarını repository'nin ana dizinine yükle.
4. GitHub'da **Actions** sekmesine gir. Android APK Build işlemi otomatik başlayacaktır.
5. İşlem bitince workflow çalışmasının içindeki **Artifacts** bölümünden `ArbeitszeitRechner-debug-apk` dosyasını indir.
6. ZIP'i aç; `app-debug.apk` Android telefona kurulabilir.

## Yerel derleme
Android Studio ile klasörü açıp Gradle senkronizasyonunu bekle. Ardından **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.

Not: Bu proje kaynak kodudur; APK dosyası GitHub Actions veya Android Studio ile derlenir.
