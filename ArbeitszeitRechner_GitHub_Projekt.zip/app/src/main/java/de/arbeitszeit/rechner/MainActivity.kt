package de.arbeitszeit.rechner

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.Duration
import java.time.format.DateTimeFormatter
import java.util.Locale

data class WorkEntry(
    val date: String,
    val start: String,
    val end: String,
    val breakMinutes: Int
) {
    fun minutesWorked(): Int {
        val s = LocalTime.parse(start)
        var e = LocalTime.parse(end)
        if (!e.isAfter(s)) e = e.plusHours(24)
        return (Duration.between(s, e).toMinutes().toInt() - breakMinutes).coerceAtLeast(0)
    }
}

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("work_data", MODE_PRIVATE) }
    private val entries = mutableListOf<WorkEntry>()
    private lateinit var dateButton: Button
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var breakInput: EditText
    private lateinit var summary: TextView
    private lateinit var listBox: LinearLayout
    private var selectedDate = LocalDate.now()
    private var startTime = "06:00"
    private var endTime = "15:00"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadEntries()
        buildScreen()
        refresh()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 18)
            setBackgroundColor(0xFFF4F6F5.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = "Arbeitszeit Rechner"
            textSize = 25f
            setTextColor(0xFF123F35.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 16)
        }
        content.addView(title)

        content.addView(label("Günlük çalışma kaydı"))
        dateButton = button("")
        dateButton.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                selectedDate = LocalDate.of(y, m + 1, d)
                dateButton.text = selectedDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show()
        }
        content.addView(dateButton)

        startButton = button("")
        startButton.setOnClickListener { chooseTime(true) }
        content.addView(label("Başlama saati"))
        content.addView(startButton)

        endButton = button("")
        endButton.setOnClickListener { chooseTime(false) }
        content.addView(label("Bitiş saati"))
        content.addView(endButton)

        content.addView(label("Mola (dakika)"))
        breakInput = EditText(this).apply {
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Örnek: 30"
            textSize = 17f
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        content.addView(breakInput, LinearLayout.LayoutParams(-1, 52))

        val save = button("Kaydet")
        save.setBackgroundColor(0xFF176B55.toInt())
        save.setTextColor(0xFFFFFFFF.toInt())
        save.setOnClickListener { saveEntry() }
        content.addView(save)

        summary = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFF18352E.toInt())
            setPadding(14, 16, 14, 16)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val summaryParams = LinearLayout.LayoutParams(-1, -2)
        summaryParams.setMargins(0, 18, 0, 12)
        content.addView(summary, summaryParams)

        content.addView(label("Kayıtlar"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)

        root.addView(TextView(this).apply {
            text = "Veriler yalnızca bu telefonda saklanır."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF66736F.toInt())
            setPadding(0, 8, 0, 0)
        })
        setContentView(root)
        updateButtons()
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF334B44.toInt())
        setPadding(0, 12, 0, 6)
    }

    private fun button(textValue: String) = Button(this).apply {
        text = textValue
        textSize = 16f
        isAllCaps = false
        setTextColor(0xFF173B32.toInt())
        setBackgroundColor(0xFFE1EAE6.toInt())
    }

    private fun chooseTime(isStart: Boolean) {
        val current = if (isStart) startTime else endTime
        val t = LocalTime.parse(current)
        TimePickerDialog(this, { _, h, m ->
            val value = String.format(Locale.GERMANY, "%02d:%02d", h, m)
            if (isStart) startTime = value else endTime = value
            updateButtons()
        }, t.hour, t.minute, true).show()
    }

    private fun updateButtons() {
        dateButton.text = selectedDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        startButton.text = startTime
        endButton.text = endTime
    }

    private fun saveEntry() {
        val breakMinutes = breakInput.text.toString().toIntOrNull() ?: 0
        if (breakMinutes < 0 || breakMinutes > 720) {
            Toast.makeText(this, "Mola süresini kontrol et.", Toast.LENGTH_SHORT).show()
            return
        }
        val entry = WorkEntry(selectedDate.toString(), startTime, endTime, breakMinutes)
        if (entry.minutesWorked() <= 0) {
            Toast.makeText(this, "Çalışma süresi mola sonrasında 0 olamaz.", Toast.LENGTH_SHORT).show()
            return
        }
        entries.removeAll { it.date == entry.date }
        entries.add(entry)
        entries.sortByDescending { it.date }
        persist()
        breakInput.setText("")
        refresh()
        Toast.makeText(this, "Kayıt kaydedildi.", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val now = LocalDate.now()
        val monthMinutes = entries.filter {
            val d = LocalDate.parse(it.date); d.year == now.year && d.monthValue == now.monthValue
        }.sumOf { it.minutesWorked() }
        val yearMinutes = entries.filter { LocalDate.parse(it.date).year == now.year }
            .sumOf { it.minutesWorked() }
        summary.text = "BU AY: ${formatMinutes(monthMinutes)}\nBU YIL: ${formatMinutes(yearMinutes)}\n\nToplamlar mola düşüldükten sonra hesaplanır."
        listBox.removeAllViews()
        entries.take(60).forEach { entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 8, 4, 8)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val info = TextView(this).apply {
                text = "${LocalDate.parse(entry.date).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))}\n${entry.start} – ${entry.end} | Mola ${entry.breakMinutes} dk\nNet: ${formatMinutes(entry.minutesWorked())}"
                textSize = 14f
                setTextColor(0xFF233B34.toInt())
            }
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val delete = Button(this).apply {
                text = "Sil"
                isAllCaps = false
                setOnClickListener {
                    entries.remove(entry); persist(); refresh()
                }
            }
            row.addView(delete)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 0, 0, 7)
            listBox.addView(row, lp)
        }
        if (entries.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Henüz kayıt yok."
                setPadding(4, 8, 4, 8)
                setTextColor(0xFF66736F.toInt())
            })
        }
    }

    private fun formatMinutes(minutes: Int): String =
        String.format(Locale.GERMANY, "%d saat %02d dakika", minutes / 60, minutes % 60)

    private fun persist() {
        val array = JSONArray()
        entries.forEach {
            array.put(JSONObject().put("date", it.date).put("start", it.start)
                .put("end", it.end).put("break", it.breakMinutes))
        }
        prefs.edit().putString("entries", array.toString()).apply()
    }

    private fun loadEntries() {
        try {
            val array = JSONArray(prefs.getString("entries", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                entries.add(WorkEntry(o.getString("date"), o.getString("start"),
                    o.getString("end"), o.optInt("break", 0)))
            }
            entries.sortByDescending { it.date }
        } catch (_: Exception) { entries.clear() }
    }
}
